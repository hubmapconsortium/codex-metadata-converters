The dataset directory must contain
experiment.json, segmentation.json, missing1.xlsx, missing2.xlsx and directories with images in format cyc001_reg001.

For EACH dataset:
1. Create missing1.xlsx and missing2.xlsx.
2. Put these files to the same directories where experiment.json.
3. Find input.xlsx in the converter directory.
4. Add the path to the directory with experiment.json to InputDir column in the input.xlsx
5. Add path where to ouput converted metadata file dataset.json to thc column OutputDir.

After all the steps are done, to run the conversion double click on file run.bat (or it may be called just run if your computer doesn't display file extensions).

If you see any errors that you cannot fix, please inform me. For this copy the infromation from the terminal window, and send log.log file that will be created in the same directory where run.bat file is.
